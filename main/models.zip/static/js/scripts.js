// Smooth Scrolling
document.querySelectorAll('header nav a').forEach(link => {
    link.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        window.scrollTo({
            top: target.offsetTop - 70,
            behavior: 'smooth',
        });
    });
});

// Back to Top Button
const backToTop = document.createElement('button');
backToTop.innerText = '↑';
backToTop.classList.add('fixed', 'bottom-10', 'right-10', 'bg-blue-600', 'text-white', 'rounded-full', 'p-3', 'hidden');
document.body.appendChild(backToTop);

window.addEventListener('scroll', () => {
    if (window.scrollY > 500) {
        backToTop.classList.remove('hidden');
    } else {
        backToTop.classList.add('hidden');
    }
});

backToTop.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});
const heroTitle = document.querySelector('.hero-title');
const words = ["Hi, I’m Jonathan", "A Creative Web Developer", "Let's Build Something Amazing"];
let i = 0;

function typeEffect() {
    heroTitle.textContent = words[i];
    i = (i + 1) % words.length;
    setTimeout(typeEffect, 3000);
}

typeEffect();
