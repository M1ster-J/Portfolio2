gsap.from("#projects", {
    duration: 1.5,
    y: 100,
    opacity: 0,
    ease: "power3.out",
    scrollTrigger: {
        trigger: "#projects",
        start: "top 80%",
    }
});