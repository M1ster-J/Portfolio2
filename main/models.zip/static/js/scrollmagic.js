var controller = new ScrollMagic.Controller();
new ScrollMagic.Scene({
    triggerElement: "#projects",
    triggerHook: 0.5,
})
.setClassToggle("#projects", "active")
.addTo(controller);